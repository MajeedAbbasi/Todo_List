let logout = document.getElementsByClassName(".logout");
      function myFunction() {
        window.location.href = "login.html";
      }
let check = document.querySelector("#check")
let Inomplete_Tasks = document.querySelector("#IncompleteTasks")


Inomplete_Tasks.addEventListener("click", function (e) {
  // let heading1 = document.querySelector(".heading1").innerText
  let div = document.createElement("div")
  div.setAttribute("class" , "task1 second")
  let input = document.createElement("input")
  input.setAttribute("type", "checkbox")
  input.checked  = true
  let heading = document.createElement("h3")
  heading.setAttribute("class", "h3")
  let headings = e.target.parentElement.lastElementChild
  let inp = e.target.parentElement.firstElementChild
  let head1 = headings.firstElementChild.innerText
  heading.innerText = head1
  div.appendChild(input)
  div.appendChild(heading)
  let complete_Tasks = document.querySelector(".complete_Tasks")
  if (inp.checked  === true) {
    complete_Tasks.insertBefore(div, complete_Tasks.firstChild);
    e.target.parentElement.remove();
  }
})
function tasksection() {
  let locationbtn = document.querySelector(".locaton")
  console.log(locationbtn);
  locationbtn.setAttribute("id","deactive" )
  let taskbtn = document.querySelector(".task")
  taskbtn.setAttribute("id" , "active")
  let tastkSection = document.querySelector("#tastkSection")
  tastkSection.setAttribute("style", "display:block")
  let locationSection = document.querySelector("#locationSection")
  locationSection.setAttribute("style", "display:none")
}
function newtask() {
  let aside = document.querySelector(".aside")
  aside.setAttribute("id",  "blur")
  let left = document.querySelector(".left")
  left.setAttribute("id",  "blur")
  
  let secondleft = document.querySelector(".secondleft")
  secondleft.setAttribute("style" , "display:block")
}

function nerw_task() {
  let first = document.getElementById("first").value
  let third = document.getElementById("third").value
  let div1 = document.createElement("div")
  div1.setAttribute("class", "task1")
  let inputfield = document.createElement("input")
  inputfield.setAttribute("type", "checkbox")
  inputfield.setAttribute("id", "check")
  inputfield.setAttribute("onclick", "completetask()")
  let div2 = document.createElement("div")
  let head1 = document.createElement("h3")
  head1.setAttribute("class", "heading1")
  head1.innerText = first
  let head2 = document.createElement("h5")
  head2.innerText = "⏰ " + third;
  div1.appendChild(inputfield)
  div2.appendChild(head1)
  div2.appendChild(head2)
  div1.appendChild(div2)
  let IncompleteTasks = document.getElementById("IncompleteTasks")
  if (first!== "" && third!=="") {
    IncompleteTasks.insertBefore(div1, IncompleteTasks.firstChild)
    let secondleft = document.querySelector(".secondleft")
    secondleft.setAttribute("style" , "display:none")
    // ********************
    let aside = document.querySelector(".aside")
  let left = document.querySelector(".left") 
  left.removeAttribute('id');
  aside.removeAttribute('id');


  }
  else{
    alert("Please set a Task")
  }
}
function cancel() {
  let secondleft = document.querySelector(".secondleft")
  secondleft.setAttribute("style" , "display:none")
  let aside = document.querySelector(".aside")
  let left = document.querySelector(".left") 
  left.removeAttribute('id');
  aside.removeAttribute('id');
}


function changeSection() {
  let locationbtn = document.querySelector(".locaton")
  locationbtn.setAttribute("id" , "active")
  let taskbtn = document.querySelector(".task")
  taskbtn.setAttribute("id" , "deactive")
  let tastkSection = document.querySelector("#tastkSection")
  tastkSection.setAttribute("style", "display:none")
  let locationSection = document.querySelector("#locationSection")
  locationSection.setAttribute("style", "display:block")
}
function popupclose() {
  document.querySelector(".popup").style.display = "none";
  
}
function popuplater() {
  document.querySelector(".popup").style.display = "none";
  if (window.location.href == "http://127.0.0.1:5500/task.html") {
    function hide() {
      document.querySelector(".popup").style.display = "block";
      }
      setTimeout(hide, 8000);
  }
}

if (window.location.href == "http://127.0.0.1:5500/task.html") {
  function hide() {
    document.querySelector(".popup").style.display = "block";
    }
    setTimeout(hide, 4000);
}
